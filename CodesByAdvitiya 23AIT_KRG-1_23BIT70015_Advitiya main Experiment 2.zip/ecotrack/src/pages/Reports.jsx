import Logs from "./Logs";

const Reports = () => {
  return (
    <div>
      <h2>Logs Section</h2>
      <Logs />
    </div>
  );
};

export default Reports;
