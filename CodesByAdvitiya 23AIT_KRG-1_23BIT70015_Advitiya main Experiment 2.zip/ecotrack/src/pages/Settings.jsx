const Settings = () => {
  return <h3>Settings Section</h3>;
};

export default Settings;
