import { Link } from "react-router-dom";

const Header = () => {
    return (
        <header style={{padding: "1rem",background:"#26d4e3",color: "white"}}>
            <h2>Ecotrac</h2>
        </header>
    )
}